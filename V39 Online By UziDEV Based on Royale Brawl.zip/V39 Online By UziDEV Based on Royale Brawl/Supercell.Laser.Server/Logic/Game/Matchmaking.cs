﻿namespace Supercell.Laser.Server.Logic.Game
{
    using Supercell.Laser.Logic.Battle;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Battle;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Logic.Team;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Server.Networking;
    using Supercell.Laser.Server.Networking.Session;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class Matchmaking
    {
        private static ConcurrentDictionary<int, MatchmakingSlot> Slots;
        private static Thread UpdateThread;

        public static void UpdateSlot(EventData e)
        {
            if (e == null) return;
            int mode;
            if (e.BattlePlayerMap != null)
                mode = e.BattlePlayerMap.GMV;
            else if (e.Location != null)
                mode = GameModeUtil.GetGameModeVariation(e.Location.GameMode);
            else return;
            int playersRequired = GamePlayUtil.GetPlayerCountWithGameModeVariation(mode);
            Slots.AddOrUpdate(e.Slot,
                _ => new MatchmakingSlot(e, playersRequired),
                (_, existing) =>
                {
                    existing.UpdateEventData(e, playersRequired);
                    return existing;
                });
        }

        public static void Init()
        {
            Slots = new ConcurrentDictionary<int, MatchmakingSlot>();

            foreach (EventData e in Events.GetEvents())
            {
                int mode;
                if (e.BattlePlayerMap != null)
                    mode = e.BattlePlayerMap.GMV;
                else if (e.Location != null)
                    mode = GameModeUtil.GetGameModeVariation(e.Location.GameMode);
                else continue;
                Console.WriteLine(mode + " MM");
                Slots.TryAdd(e.Slot, new MatchmakingSlot(e, GamePlayUtil.GetPlayerCountWithGameModeVariation(mode)));
            }

            UpdateThread = new Thread(Update);
            UpdateThread.Start();
        }

        private static void Update()
        {
            while (true)
            {
                try
                {
                    foreach (MatchmakingSlot slot in Slots.Values)
                    {
                        try { slot.Update(); }
                        catch (Exception ex) { Logger.Error($"Matchmaking slot update failed: {ex.GetType().Name}"); }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Matchmaking update loop recovered from {ex.GetType().Name}");
                }
                Thread.Sleep(250);
            }
        }
        
        public static bool IsBannedRankedMode(int gameModeVariation)
    {
        return gameModeVariation == 300;
    }
    

        public static void RequestMatchmake(Connection connection, int slot, long team = -1)
        {
            if (!Slots.TryGetValue(slot, out MatchmakingSlot matchmakingSlot)) return;

            connection.MatchmakeSlot = slot;
            MatchmakingEntry entry = new MatchmakingEntry(connection);
            entry.PlayerTeamId = team;
            connection.MatchmakingEntry = entry;
            matchmakingSlot.Add(entry);
        }

        public static void CancelMatchmake(Connection connection)
        {
            int slot = connection.MatchmakeSlot;
            if (Slots.TryGetValue(slot, out MatchmakingSlot matchmakingSlot))
            {
                connection.MatchmakeSlot = -1;
                matchmakingSlot.Remove(connection.MatchmakingEntry);

                if (connection.MatchmakingEntry.PlayerTeamId > 0)
                {
                    TeamEntry team = Teams.Get(connection.MatchmakingEntry.PlayerTeamId);

                    foreach (TeamMember member in team.Members)
                    {
                        member.IsReady = false;
                        Session session = Sessions.GetSession(member.AccountId);
                        if (session != null)
                        {
                            session.Connection.MatchmakingEntry.PlayerTeamId = -1;
                            CancelMatchmake(session.Connection);
                            MatchMakingCancelledMessage cancelled = new MatchMakingCancelledMessage();
                            session.Connection.Send(cancelled);
                        }
                    }

                    team.TeamUpdated();
                }
            } 
        }
    }

    public class MatchmakingSlot
    {
        private ConcurrentQueue<MatchmakingEntry> RequestQueue;
        private ConcurrentQueue<MatchmakingEntry> RemoveQueue;

        private List<MatchmakingEntry> Queue;

        private int PlayersRequired;
        private EventData EventData;

        private int SecondsLeft;
        private int Turns;

        public const int SEARCH_TIMEOUT = 7;
        
        public bool IsRanked => EventData.Slot == 14 || EventData.Slot == 15 || EventData.Slot == 16;

        public MatchmakingSlot(EventData eventData, int playersRequired)
        {
            PlayersRequired = playersRequired;
            EventData = eventData;
            Queue = new List<MatchmakingEntry>();

            RequestQueue = new ConcurrentQueue<MatchmakingEntry>();
            RemoveQueue = new ConcurrentQueue<MatchmakingEntry>();

            SecondsLeft = SEARCH_TIMEOUT;
        }

        public void UpdateEventData(EventData eventData, int playersRequired)
        {
            EventData = eventData;
            PlayersRequired = playersRequired;
        }

        public void Update()
{
    try
    {
        if (Sessions.Maintenance) return;
        
        if (IsRanked)
    {
        int gameModeVariation = EventData.Location != null
            ? GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation)
            : (EventData.BattlePlayerMap != null ? EventData.BattlePlayerMap.GMV : 0);
        if (Matchmaking.IsBannedRankedMode(gameModeVariation)) return;
        PlayersRequired = GamePlayUtil.GetPlayerCountWithGameModeVariation(gameModeVariation);
    }
    else
    {
        //int gameModeVariation = GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation);
       // PlayersRequired = gameModeVariation == 6 ? 10 : 6;
    }


        foreach (MatchmakingEntry entry in Queue)
        {
            if (!entry.Connection.IsOpen) Remove(entry);
        }

        while (RemoveQueue.TryDequeue(out MatchmakingEntry removedEntry))
        {
            Queue.Remove(removedEntry);
        }

        while (RequestQueue.TryDequeue(out MatchmakingEntry entry))
        {
            MatchmakingEntry check = Queue.Find(x => x.Connection == entry.Connection);
            if (check != null) continue;

            Queue.Add(entry);
        }

        if (Queue.Count == 0)
        {
            Turns = 0;
            SecondsLeft = SEARCH_TIMEOUT;
            return;
        }

        while (Queue.Count >= PlayersRequired)
        {
            List<MatchmakingEntry> batch = Queue.Take(PlayersRequired).ToList();
            TryStartGame(batch);
            Queue.RemoveRange(0, batch.Count);
        }

        if (Queue.Count > 0 && Queue.Count < PlayersRequired && SecondsLeft <= 0)
        {
            SecondsLeft = SEARCH_TIMEOUT;
            List<MatchmakingEntry> batch = Queue.ToList();
            TryStartGame(batch);
            Queue.Clear();
        }

        if (Queue.Count > 0)
        {
            Turns++;
            if (Turns >= 4)
            {
                Turns = 0;
                SecondsLeft--;
            }
        }
        else
        {
            Turns = 0;
            SecondsLeft = SEARCH_TIMEOUT;
        }

        if (Queue.Count > 0)
        {
            MatchMakingStatusMessage message = new MatchMakingStatusMessage();

            message.Seconds = SecondsLeft;
            message.Found = Queue.Count;
            message.Max = PlayersRequired;
            message.ShowTips = true;

            foreach (MatchmakingEntry entry in Queue)
            {
                entry.Connection.Messaging.Send(message);
            }
        }
    } 
    catch (Exception e)
    {
        Console.WriteLine("GameMatchmakingManager exception!");
        Console.WriteLine($"{e.GetType().Name}, {e.Message}\n{e.StackTrace}");
    }
}
        public void Remove(MatchmakingEntry entry)
        {
            RemoveQueue.Enqueue(entry);
        }

        public void Add(MatchmakingEntry entry)
        {
            RequestQueue.Enqueue(entry);
        }
        
        
/*
        public async Task StartRankedMatch(List<MatchmakingEntry> entries)
{
    if (entries == null || entries.Count < 2)
        return;

    var validEntries = new List<MatchmakingEntry>();

    foreach (var entry in entries)
    {
        if (entry?.Connection?.IsOpen == true && entry.Connection.Avatar != null)
            validEntries.Add(entry);
        else if (entry != null)
            Remove(entry);
    }

    if (validEntries.Count < 2)
        return;

    RankedMatch ranked = new RankedMatch(false);
    ranked.MatchId = RankedMatchRegulator.Add(ranked);
    ranked.IsSoloMatch = this.EventData.Slot == 14;

    var e1 = validEntries[0];
    var e2 = validEntries[1];

    e1.Connection.Avatar.RankedId = (int)ranked.MatchId;
    e2.Connection.Avatar.RankedId = (int)ranked.MatchId;

    var p1 = mp_thestealdev.CreateRankedPlayer(
        e1.Connection.Avatar,
        e1.Connection.Home,
        0,
        0
    );

    var p2 = mp_thestealdev.CreateRankedPlayer(
        e2.Connection.Avatar,
        e2.Connection.Home,
        1,
        3
    );

    ranked.AddMatchPlayer(p1);
    ranked.AddMatchPlayer(p2);

    try
    {
        ranked.Start();
    }
    catch
    {
        Remove(e1);
        Remove(e2);
    }
}*/


/*
        public async Task StartRankedMatch(List<MatchmakingEntry> entries)
{
    if (entries == null || entries.Count < 1)
        return;

    List<MatchmakingEntry> validEntries = new List<MatchmakingEntry>();

    foreach (var entry in entries)
    {
        if (entry?.Connection?.IsOpen == true && entry.Connection.Avatar != null)
            validEntries.Add(entry);
        else if (entry != null)
            Remove(entry);
    }

    RankedMatch ranked = new RankedMatch(false);
    ranked.MatchId = RankedMatchRegulator.Add(ranked);
    ranked.IsSoloMatch = (this.EventData.Slot == 14);

    var groups = validEntries
        .GroupBy(x => x.PlayerTeamId)
        .OrderByDescending(g => g.Count())
        .ToList();

    List<MatchmakingEntry> team0 = new List<MatchmakingEntry>();
    List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();

    foreach (var group in groups)
    {
        foreach (var p in group)
        {
            if (team0.Count < 3)
                team0.Add(p);
            else if (team1.Count < 3)
                team1.Add(p);
        }
    }

    int globalIndex = 0;

    for (int i = 0; i < team0.Count; i++)
    {
        var entry = team0[i];

        entry.Connection.Avatar.RankedId = Convert.ToInt32(ranked.MatchId);

        var player = mp_thestealdev.CreateRankedPlayer(
            entry.Connection.Avatar,
            entry.Connection.Home,
            0,
            globalIndex++);

        ranked.AddMatchPlayer(player);
    }

    for (int i = 0; i < team1.Count; i++)
    {
        var entry = team1[i];

        entry.Connection.Avatar.RankedId = Convert.ToInt32(ranked.MatchId);

        var player = mp_thestealdev.CreateRankedPlayer(
            entry.Connection.Avatar,
            entry.Connection.Home,
            1,
            globalIndex++);

        ranked.AddMatchPlayer(player);
    }

    try
    {
        ranked.Start();
    }
    catch
    {
        foreach (var entry in validEntries)
        {
            if (entry != null)
                Remove(entry);
        }
    }
}*/


public async Task StartRankedMatch(List<MatchmakingEntry> entries)
{
    Console.WriteLine($"[StartRankedMatch] slot={EventData.Slot} IsSolo={EventData.Slot == 14} entries={entries?.Count ?? 0}");
    if (entries == null || entries.Count < 1)
        return;

    List<MatchmakingEntry> validEntries = new List<MatchmakingEntry>();

    foreach (var entry in entries)
    {
        if (entry?.Connection?.IsOpen == true && entry.Connection.Avatar != null)
            validEntries.Add(entry);
        else if (entry != null)
            Remove(entry);
    }

    RankedMatch ranked = new RankedMatch(false);
    ranked.MatchId = RankedMatchRegulator.Add(ranked);
    ranked.IsSoloMatch = (this.EventData.Slot == 14);

    List<MatchmakingEntry> team0 = new();
    List<MatchmakingEntry> team1 = new();

    Dictionary<long, int> partyTeam = new Dictionary<long, int>();
    int toggle = 0;

    foreach (var entry in validEntries)
    {
        int assignedTeam;
        if (entry.PlayerTeamId > 0 && partyTeam.ContainsKey(entry.PlayerTeamId))
        {
            assignedTeam = partyTeam[entry.PlayerTeamId];
        }
        else
        {
            assignedTeam = toggle % 2;
            toggle++;
            if (entry.PlayerTeamId > 0)
                partyTeam[entry.PlayerTeamId] = assignedTeam;
        }

        if (assignedTeam == 0)
            team0.Add(entry);
        else
            team1.Add(entry);
    }

    int globalIndex = 0;

    for (int i = 0; i < team0.Count; i++)
    {
        var entry = team0[i];

        entry.Connection.Avatar.RankedId = Convert.ToInt32(ranked.MatchId);

        var player = mp_thestealdev.CreateRankedPlayer(
            entry.Connection.Avatar,
            entry.Connection.Home,
            0,
            i);

        player.GlobalIndex = globalIndex++;

        ranked.AddMatchPlayer(player);
    }

    for (int i = 0; i < team1.Count; i++)
    {
        var entry = team1[i];

        entry.Connection.Avatar.RankedId = Convert.ToInt32(ranked.MatchId);

        var player = mp_thestealdev.CreateRankedPlayer(
            entry.Connection.Avatar,
            entry.Connection.Home,
            1,
            i);

        player.GlobalIndex = globalIndex++;

        ranked.AddMatchPlayer(player);
    }

    try
    {
        ranked.Start();
    }
    catch
    {
        foreach (var entry in validEntries)
        {
            if (entry != null)
                Remove(entry);
        }
    }
}
private mp_thestealdev CreateRankedBotPlayer(int botCharacterGlobalId, int globalIndex, int teamIndex, int rankedId)
{
    var botPlayer = new mp_thestealdev();
    
    botPlayer.AccountId = -Math.Abs(globalIndex + 1);
    botPlayer.GlobalIndex = globalIndex;
    botPlayer.TeamIndex = teamIndex;
    botPlayer.Position = globalIndex;
    botPlayer.CharacterPreview = botCharacterGlobalId;
   // botPlayer.BannedBrawler = 0;
  //  botPlayer.BanState = 0;
   // botPlayer.PickState = 1;
    
    botPlayer.DisplayData = new PlayerDisplayData(false, 0, 0, $"Bot_{globalIndex}");
    
    var charData = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacterGlobalId);
    if (charData != null)
    {
    }
    
    return botPlayer;
}
        public static int[] botBrawlers = null;

        public static int[] GetBotBrawlers()
        {
            if (botBrawlers == null)
            {
                var table = DataTables.Get(DataType.Character);
                var ids = new System.Collections.Generic.List<int>();
                for (int i = 0; i < table.Count; i++)
                {
                    var cd = table.GetDataWithId<CharacterData>(i);
                    if (cd == null) continue;
                    if (cd.Type != "Hero") continue;
                    ids.Add(i);
                }
                botBrawlers = ids.ToArray();
            }
            return botBrawlers;
        }
       
        private bool LastStartSucceeded;

        private bool TryStartGame(List<MatchmakingEntry> entries)
        {
            LastStartSucceeded = false;
            try
            {
                StartGame(entries);
            }
            catch (Exception ex)
            {
                LastStartSucceeded = false;
                Console.WriteLine($"Matchmaking battle start failed: {ex.GetType().Name}");
            }
            if (!LastStartSucceeded)
            {
                foreach (MatchmakingEntry entry in entries)
                {
                    try
                    {
                        if (entry?.Connection?.IsOpen == true) entry.Connection.Send(new MatchMakingCancelledMessage());
                    }
                    catch { }
                }
            }
            return LastStartSucceeded;
        }

        public void StartGame(List<MatchmakingEntry> entries)
        {
            LastStartSucceeded = false;
            // The battle inits here
            // TODO: Merge it to BattleManager or smth..
            Console.WriteLine($"[MatchmakingSlot.StartGame] slot={EventData.Slot} IsRanked={IsRanked} entries={entries.Count} LocationId={EventData.LocationId}");
            if(IsRanked) 
            {
                StartRankedMatch(entries);
                LastStartSucceeded = true;
                return;
            }
            	

            BattleMode battle;
            if (EventData.BattlePlayerMap != null)
            {
                battle = new BattleMode(EventData.BattlePlayerMap);
            }
            else
            {
                battle = new BattleMode(EventData.LocationId);
                if (battle.Location == null)
                {
                    Console.WriteLine($"[Matchmaking] StartGame: Location is null for LocationId={EventData.LocationId}, slot={EventData.Slot}");
                    return;
                }
            }
            if (EventData.BattlePlayerMap != null) battle.SetPlayerMap(EventData.BattlePlayerMap);
            battle.Id = Battles.Add(battle);

            Random rand = new Random();

            List<MatchmakingEntry> sortedEntries = new List<MatchmakingEntry>();
            Dictionary<long, List<MatchmakingEntry>> teamEntries = new Dictionary<long, List<MatchmakingEntry>>();

            if (GameModeUtil.HasTwoTeams(battle.GetGameModeVariation()))
            {
                MatchmakingEntry[] entriesWithTeam = entries.FindAll(entry => entry.PlayerTeamId > 0).ToArray();
                for (int i = 0; i < entriesWithTeam.Length; i++)
                {
                    MatchmakingEntry entry = entriesWithTeam[i];
                    long teamId = entry.PlayerTeamId;
                    if (!teamEntries.ContainsKey(teamId)) teamEntries.Add(teamId, new List<MatchmakingEntry>());
                    teamEntries[teamId].Add(entry);
                    entries.Remove(entry);
                }

                long[] ids = teamEntries.Keys.ToArray();
                for (int i = 0; i < ids.Length; i++)
                {
                    List<MatchmakingEntry> teamedEntries = teamEntries[ids[i]];
                    for (int j = 0; j < teamedEntries.Count; j++)
                    {
                        sortedEntries.Add(teamedEntries[j]);
                        teamedEntries[j].PrefferedTeam = i;
                    }
                }

                for (int i = 0; i < entries.Count; i++)
                {
                    sortedEntries.Add(entries[i]);
                }

                for (int i = 0; i < sortedEntries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = i % 2;
                    if (sortedEntries[i].PrefferedTeam != -1)
                    {
                        teamIndex = sortedEntries[i].PrefferedTeam;
                    }

                    if (battle.GetTeamPlayersCount(teamIndex) >= 3)
                    {
                        if (teamIndex == 1) teamIndex = 0;
                        else teamIndex = 1;
                    }
                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex, enableGadget: battle.GetGameModeVariation() == 13);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                List<int> team1BotsCharacters = new List<int>();
                List<int> team2BotsCharacters = new List<int>();

                for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    bool isBotValid = false;

                    int botCharacter = -1;
                    while (!isBotValid)
                    {
                        botCharacter = 16000000 + GetBotBrawlers()[rand.Next(0, GetBotBrawlers().Length)];
                        if (i % 2 == 0)
                        {
                            isBotValid = !team1BotsCharacters.Contains(botCharacter);
                        }
                        else
                        {
                            isBotValid = !team2BotsCharacters.Contains(botCharacter);
                        }
                        if (!isBotValid) isBotValid = !GameModeUtil.HasTwoTeams(battle.GetGameModeVariation());
                    }

                    int teamIndex = i % 2;
                    if (battle.GetTeamPlayersCount(teamIndex) >= 3)
                    {
                        if (teamIndex == 1) teamIndex = 0;
                        else teamIndex = 1;
                    }

                    if (teamIndex == 0)
                    {
                        team1BotsCharacters.Add(botCharacter);
                    }
                    else
                    {
                        team2BotsCharacters.Add(botCharacter);
                    }
                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                  BattlePlayer bot = BattlePlayer.CreateBotInfo(data.ItemName.ToUpper(), i, teamIndex, botCharacter);
                   battle.AddPlayer(bot, -1);
                }
            }
            else
            {
                if (battle.GetGameModeVariation() == 9)
                {
                    List<MatchmakingEntry> withTeam = entries.Where(e => e.PlayerTeamId > 0).ToList();
                    List<MatchmakingEntry> solo = entries.Where(e => e.PlayerTeamId <= 0).ToList();

                    Dictionary<long, List<MatchmakingEntry>> grouped = new Dictionary<long, List<MatchmakingEntry>>();
                    foreach (var e in withTeam)
                    {
                        if (!grouped.ContainsKey(e.PlayerTeamId)) grouped[e.PlayerTeamId] = new List<MatchmakingEntry>();
                        grouped[e.PlayerTeamId].Add(e);
                    }

                    sortedEntries = new List<MatchmakingEntry>();
                    foreach (var group in grouped.Values)
                        sortedEntries.AddRange(group);
                    sortedEntries.AddRange(solo);
                }
                else
                {
                    sortedEntries = entries;
                }

                for (int i = 0; i < sortedEntries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = battle.GetGameModeVariation() == 9 ? i / 2 : i;
                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex, enableGadget: battle.GetGameModeVariation() == 13);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    int botCharacter = 16000000 + GetBotBrawlers()[rand.Next(0, GetBotBrawlers().Length)];
                    int teamIndex = battle.GetGameModeVariation() == 9 ? i / 2 : i;
                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo(data.ItemName.ToUpper(), i, teamIndex, botCharacter);
                    battle.AddPlayer(bot, -1);
                }
            }

            battle.AddGameObjects();

            for (int i = 0; i < sortedEntries.Count; i++)
            {
                StartLoadingMessage startLoading = new StartLoadingMessage();
                startLoading.LocationId = battle.Location.GetGlobalId();
                startLoading.TeamIndex = sortedEntries[i].Player.TeamIndex;
                startLoading.OwnIndex = sortedEntries[i].Player.PlayerIndex;
                startLoading.GameMode = battle.GetGameModeVariation() == 6 ? 6 : battle.GetGameModeVariation() == 9 ? 9 : 1;
                startLoading.SetPlayerMap(battle.BattlePlayerMap);

                sortedEntries[i].Connection.Avatar.UdpSessionId = sortedEntries[i].Connection.UdpSessionId;
                startLoading.Players.AddRange(battle.GetPlayers());
                sortedEntries[i].Connection.Send(startLoading);
                battle.BattleWithTrophies = true;
            }

            battle.Start();
            LastStartSucceeded = true;
        }
    }

    public class MatchmakingEntry
    {
        public readonly Connection Connection;
        public BattlePlayer Player;
        public long PlayerTeamId;

        public int PrefferedTeam;

        public MatchmakingEntry(Connection connection)
        {
            PrefferedTeam = -1;
            this.Connection = connection;
        }
    }
}