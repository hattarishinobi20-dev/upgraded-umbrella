﻿namespace Supercell.Laser.Logic
{
    public class GameVersion
    {
        public const int MAJOR = 39;
        public const int BUILD = 99;
    }
}