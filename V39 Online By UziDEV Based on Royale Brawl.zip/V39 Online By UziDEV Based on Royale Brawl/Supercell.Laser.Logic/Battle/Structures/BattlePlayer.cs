﻿namespace Supercell.Laser.Logic.Battle.Structures
{
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Avatar.Structures;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Math;
    using Supercell.Laser.Titan.Util;

    public class TickDamage
    {
        public int Tick { get; set; }
        public int Damage { get; set; }
    }
    public class BattlePlayer
    {
        public long AccountId;
        public int PlayerIndex;
        public int TeamIndex;
        public Dictionary<int, int> Emotes = new Dictionary<int, int>();
        public Dictionary<int, int> Spray = new Dictionary<int, int>();
        public long TeamId = -1;
        public int HeroIndex;
        public int HeroIndexMax;
        public PlayerDisplayData DisplayData;
        public int CharacterId => CharacterIds[HeroIndex];
        public int SkinId => SkinIds[HeroIndex];
        public long SessionId;
        public LogicGameListener GameListener;
        public int[] CharacterIds = new int[3];
        public int[] SkinIds = new int[3];
        public int OwnObjectId;
        public int PreviousObjectId;
        public int ControlTicksLeft;
        public int LastHandledInput;
        public int Trophies, HighestTrophies;
        public int HeroPowerLevel;
        private int Score;
        private LogicVector2 SpawnPoint;
        public bool RespawnStarted;
        public int RespawnX;
        public int RespawnY;
        public int StartUsingPinTicks;
        public int LastPinUseTicks;
        public int PinIndex;
        public int SprayIndex;
        public SkinConfData SkinConfData => SkinId == 0 ? null : DataTables.Get(DataType.SkinConf).GetData<SkinConfData>(DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(SkinId).Conf);
        public SkinData SkinData => SkinId == 0 ? null : DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(SkinId);
        public CardData AccessoryCardData => AccessoryCardDatas[HeroIndex];
        public CardData[] AccessoryCardDatas;
        public AccessoryData AccessoryData => AccessoryDatas[HeroIndex];
        public AccessoryData[] AccessoryDatas;
        public CardData StarPowerData => StarPowerDatas[HeroIndex];
        public CardData[] StarPowerDatas;
        public Accessory Accessory;
        public CharacterData CharacterData => CharacterDatas[HeroIndex];
        public CharacterData[] CharacterDatas;
        public CardData[] OverChargeDatas;
        public CardData OverChargeData => OverChargeDatas[HeroIndex];
        public int PowerLevel;
        public int Bot;
        public bool IsAdmin;
        private int UltiCharge;
        private int OverCharge;
        public bool OverCharging;
        public bool OverChargeActivated;
        public bool OverChargeStarted;
        public bool OverChargeEnded;
        public bool IsAlive;
        public int BattleRoyaleRank;
        public List<PlayerKillEntry> KillList;
        public int Kills;
        public int Damage;
        public int Heals;
        public int DeathTick;
        public int Deaths;
        public List<TickDamage> _damageHistory = new();
        public List<Item> BoMines = new();
        public bool HasStar;
        public int EventCollectTokens;
        public int TemporaryTeamOverride;
		public bool BattleEndSent;

        public BattlePlayer()
        {
            DisplayData = new PlayerDisplayData();
            SpawnPoint = new LogicVector2();

            StartUsingPinTicks = -9999;
            LastPinUseTicks = -9999;

            BattleRoyaleRank = -1;

            KillList = new List<PlayerKillEntry>();
            UltiCharge = 0;

         // UltiCharge = 0;
            OverCharge = 0;
            DeathTick = 1;
        }
        public void Healed(int heals)
        {
            Heals += heals;
        }

        public int GetDps(Int64 a1 = 0)
        {
            return _damageHistory.Sum(d => d.Damage);
        }
        public void DamageDealed(int damage, int currentTick = 0)
        {
            Damage += damage;
            if (damage > 0)
            {
                _damageHistory.Add(new TickDamage { Tick = currentTick, Damage = damage });
            }
        }

        public int GetSprayIDBySprayIndex(int i)
        {
            return Spray[i];
        }

        public void KilledPlayer(int index, int bountyStars)
        {
            KillList.Add(new PlayerKillEntry()
            {
                PlayerIndex = index,
                BountyStarsEarned = bountyStars
            });

            Kills++;
        }

        public bool HasUlti()
        {
            return UltiCharge >= 4000;
        }

        public bool OverChargeReady()
        {
            return OverCharge >= 4000;
        }

        public int GetUltiCharge()
        {
            return UltiCharge;
        }

        public int GetOverCharge()
        {
            return OverCharge;
        }
        public int GetCardValueForPassive(string a2, int a3)
        {
            if (StarPowerData != null)
            {
                if (StarPowerData.Type == a2)
                {
                    if (a3 == 2) return StarPowerData.Value3;
                    return a3 > 0 ? StarPowerData.Value : StarPowerData.Value2;
                }
                else return -1;

            }
            else
                return -1;
        }
        public void AddUltiCharge(int amount)
        {
            UltiCharge = LogicMath.Clamp(UltiCharge + amount, 0, 4000);
        }
        public int GetGearBoost(int LogicType)
        {
            return 0;
        }
        public void ChargeUlti(int a2, bool a3, bool a4)
        {
            UltiCharge += a2;
        }

        public void UseUlti()
        {
            if (!IsAdmin) UltiCharge = 0;
            UltiCharge = 0;
        }
        public int IsBot()
        {
            return Bot;
        }

        public BattlePlayer(ClientHome home, ClientAvatar avatar) : this()
        {
            Home = home;
            Avatar = avatar;
        }

        public void AddScore(int a)
        {
            Score += a;
        }

        public void ResetScore()
        {
            Score = 0;
        }

        public void UsePin(int index, int ticks)
        {
            StartUsingPinTicks = ticks;
            PinIndex = index;
            LastPinUseTicks = ticks;
        }

        public bool IsUsingPin(int ticks)
        {
            return ticks - StartUsingPinTicks < 80;
        }
        
        public void ResetUsingPin()
        { 
        	StartUsingPinTicks = -1;
            LastPinUseTicks = -1;
        }

        public void SetHeroIndex(int Index)
        {
            HeroIndex = Index;
            Accessory = AccessoryDatas[Index] == null ? null : new Accessory(AccessoryDatas[Index]);

        }
        public int GetScore()
        {
            return Score;
        }

        public void SetSpawnPoint(int x, int y)
        {
            SpawnPoint.Set(x, y);
        }

        public void SetSpawnPoint(LogicVector2 pos)
        {
            SpawnPoint = pos;
        }

        public LogicVector2 GetSpawnPoint()
        {
            return SpawnPoint.Clone();
        }
        public bool HasOverCharge()
        {
            return OverChargeData != null;
        }

        public void Encode(ByteStream stream)
        {
        	Console.WriteLine("bt");
            stream.WriteLong(AccountId);
            stream.WriteVInt(PlayerIndex);
            stream.WriteVInt(TeamIndex);
            stream.WriteVInt(0); //unk
            stream.WriteInt(0); //unk

            ByteStreamHelper.WriteDataReference(stream, CharacterId); //character
            ByteStreamHelper.WriteDataReference(stream, SkinIds[0]); //skin
            
            stream.WriteBoolean(true); //card data: starpower, accesory.. 
            stream.WriteVInt(HeroPowerLevel); //hero lvl
            ByteStreamHelper.WriteDataReference(stream, StarPowerDatas[0]); //star
            //ByteStreamHelper.WriteDataReference(stream, null); 
            ByteStreamHelper.WriteDataReference(stream, AccessoryCardDatas[0]); //gadget

            if (stream.WriteBoolean(true))
                {
                    stream.WriteVInt(5);
                    ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(52, Emotes.TryGetValue(1, out var value) ? value : 137 - 3));
                    ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(52, Emotes.TryGetValue(2, out var value2) ? value2 : 137 - 3));
                    ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(52, Emotes.TryGetValue(3, out var value3) ? value3 : 137 - 3));

                    ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(52, Emotes.TryGetValue(4, out var value4) ? value4 : 137 - 3));
                    ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(52, Emotes.TryGetValue(5, out var value5) ? value5 : 137 - 3));
                }
            
            DisplayData.Encode(stream);
            stream.WriteBoolean(false); //unk
        }


/*
public class LogicHeroUpgrades
{
    public void Encode(ByteStream byteStream, List<LogicCardData> cardInfo)
    {
        byteStream.WriteVInt(0);
        ByteStreamHelper.WriteDataReference(byteStream, cardInfo[0].GetGlobalId());
        ByteStreamHelper.WriteDataReference(byteStream, cardInfo[1].GetGlobalId());
    }
}

public void Encode(ByteStream byteStream)
    {
        new LogicLong(0, (int)(!_isBot
            ? _accountModel.GetAccountModel().GetAccountId()
            : 10000000 + Helper.GenerateRandomIntForBetween(100, 200))).Encode(byteStream);
        byteStream.WriteVInt(_playerIndex);
        byteStream.WriteVInt(_teamIndex);
        byteStream.WriteVInt(0);
        byteStream.WriteInt(0);
        ByteStreamHelper.WriteDataReference(byteStream, GlobalId.CreateGlobalId(16, HeroInfo[0]));
        ByteStreamHelper.WriteDataReference(byteStream, HeroInfo[3] > 0 ? 29000000 + HeroInfo[3] : 0);

        if (byteStream.WriteBoolean(CardInfo.Count > 1)) new LogicHeroUpgrades().Encode(byteStream, CardInfo);
        if (byteStream.WriteBoolean(true)) new LogicBattleEmotes().Encode(byteStream);

        _playerDisplayData.Encode(byteStream);
        byteStream.WriteBoolean(false);
    }*/
    
        [JsonIgnore] public readonly ClientHome Home;
        [JsonIgnore] public readonly ClientAvatar Avatar;

        public static BattlePlayer Create(ClientHome home, ClientAvatar avatar, int playerIndex, int teamIndex, EventData eventData = null, int characterid = -1, bool enableGadget = false)
{
    BattlePlayer player = new BattlePlayer(home, avatar);
    player.DisplayData.Name = avatar.Name;
    player.DisplayData.ThumbnailId = home.ThumbnailId;
    player.DisplayData.NameColorId = home.NameColorId;
    if (avatar.Name.StartsWith("<c"))
    {
        player.DisplayData.HighNameColorId = -1;
    }
    else
    {
        player.DisplayData.HighNameColorId = home.HasPremiumPass || home.NameColorId == 43000012 ? home.NameColorId : 0;
    }

    player.AccessoryCardDatas = new CardData[3];
    player.AccessoryDatas = new AccessoryData[3];
    player.StarPowerDatas = new CardData[3];
    player.CharacterDatas = new CharacterData[3];
    player.OverChargeDatas = new CardData[3];

    player.AccountId = avatar.AccountId;
    Hero geroin = null;

    int selectedCharacterId = characterid == -1 ? home.CharacterId : characterid;

    for (int i = 0; i < 1; i++)
    {
        player.CharacterIds[i] = selectedCharacterId;

        Hero hero1 = avatar.GetHero(selectedCharacterId);

        if (hero1 != null && hero1.SelectedSkinId > 0)
        {
            player.SkinIds[i] = GlobalId.CreateGlobalId(29, hero1.SelectedSkinId);
        }

        if (hero1 != null && hero1.Emotes != null && hero1.Emotes.Count > 0)
        {
            if (hero1.Emotes.TryGetValue(1, out int emote1)) player.Emotes[1] = emote1;
            if (hero1.Emotes.TryGetValue(2, out int emote2)) player.Emotes[2] = emote2;
            if (hero1.Emotes.TryGetValue(3, out int emote3)) player.Emotes[3] = emote3;
        }
            CardData gadgetCard = null;
            AccessoryData accessoryData = null;
            if (hero1.SelectedGadgetId > 0)
            {
                CardData tmp = DataTables.Get(23).GetData<CardData>(hero1.SelectedGadgetId);
                if (tmp != null && avatar.UnlockedMeta.Contains(tmp.GetGlobalId()))
                {
                    gadgetCard = tmp;
                    accessoryData = DataTables.Get(DataType.Accessory).GetData<AccessoryData>(tmp.Name);
                }
            }
            player.AccessoryCardDatas[i] = gadgetCard;
            player.AccessoryDatas[i] = accessoryData;


        CardData starPowerData = null;
if (hero1.SelectedStarPowerId > 0)
{
    CardData tmp = DataTables.Get(23).GetData<CardData>(hero1.SelectedStarPowerId);
    if (tmp != null && avatar.UnlockedMeta.Contains(tmp.GetGlobalId()))
    {
        starPowerData = tmp;
    }
}
        player.StarPowerDatas[0] = starPowerData;
        player.CharacterDatas[0] = DataTables.Get(DataType.Character).GetDataWithId<CharacterData>(selectedCharacterId);
        geroin = hero1;
}

    player.Accessory = player.AccessoryData == null ? null : new Accessory(player.AccessoryData);

    if (home.PlayerSelectedEmotes != null && home.PlayerSelectedEmotes.Count > 0)
    {
        if (home.PlayerSelectedEmotes.TryGetValue(4, out int emote4)) player.Emotes[4] = emote4;
        if (home.PlayerSelectedEmotes.TryGetValue(5, out int emote5)) player.Emotes[5] = emote5;
    }
    player.PlayerIndex = playerIndex;
    player.TeamIndex = teamIndex;

    Hero hero = avatar.GetHero(selectedCharacterId);

    // player.Gear1 = DataTables.Get(DataType.Gear).GetDataWithId<GearData>(0);
    // player.Gear2 = DataTables.Get(DataType.Gear).GetDataWithId<GearData>(0);

    if (hero != null)
    {
        player.Trophies = hero.Trophies;
        player.HighestTrophies = hero.HighestTrophies;
        player.HeroPowerLevel = hero.PowerLevel;
    }

    //player.GameListener = new LogicGameListener();
    //player.HeroIndex = 1;

    return player;
}

        public static BattlePlayer CreateBotInfo(string name, int playerIndex, int teamIndex, int character = 16000000)
        {

            BattlePlayer player = new BattlePlayer();
            player.AccessoryCardDatas = new CardData[3];
            player.AccessoryDatas = new AccessoryData[3];
            player.StarPowerDatas = new CardData[3];
            player.CharacterDatas = new CharacterData[3];
            player.OverChargeDatas = new CardData[3];
            //player.AccessoryDatas[0] = DataTables.Get(DataType.Accessory).GetData<AccessoryData>("ShotgunGirl_Dash");
           // player.AccessoryCardDatas[0] = DataTables.Get(23).GetData<CardData>("ShotgunGirl_Dash");
            //player.Accessory = new Accessory(player.AccessoryData);
            CharacterData selectedCharacter = DataTables.Get(DataType.Character).GetDataByGlobalId<CharacterData>(character);
            player.DisplayData.Name = selectedCharacter?.Name?.ToUpperInvariant() ?? name?.ToUpperInvariant() ?? "BOT";
            player.DisplayData.ThumbnailId = GlobalId.CreateGlobalId(28, 0);
            player.DisplayData.NameColorId = GlobalId.CreateGlobalId(43, 0);
            player.DisplayData.HighNameColorId = GlobalId.CreateGlobalId(46, 0);
            player.AccountId = 100000 + playerIndex;
            player.CharacterIds[0] = (character);
            //player.AccessoryCardDatas[0] = DataTables.Get(23).GetData<CardData>(255);
            //player.AccessoryDatas[0] = DataTables.Get(DataType.Accessory).GetData<AccessoryData>(player.AccessoryCardData.Name);
            //player.AccessoryUsesLeft = 3;
            player.PlayerIndex = playerIndex;
            player.TeamIndex = teamIndex;
            player.SessionId = -1;
            player.Bot = 1;
            player.CharacterDatas[0] = selectedCharacter;
            player.SkinIds[0] = 0;
            player.HeroPowerLevel = new Random().Next(5, 9);
            player.HeroIndexMax = 0;
            return player;
        }
    }
}
