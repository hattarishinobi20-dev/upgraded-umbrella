﻿namespace Supercell.Laser.Logic.Battle.Objects
{
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Math;

    public class GameObject
    {
        public int TicksGone => GetBattle().GetTicksGone();

        protected int DataId;
        protected GameObjectManager GameObjectManager;

        private int Index;
        public int TeamIndex = -1;
        private int FadeCounter;
        public int ObjectGlobalId;
        private int CloneOfObjectGlobalId;

        public bool IsInRealm;

        protected LogicVector2 Position;
        protected int Z;
        public int RenderZ = -1;
        public int Scale;
        public int UID;

        public GameObject(int classId, int instanceId)
        {
            DataId = GlobalId.CreateGlobalId(classId, instanceId);

            Position = new LogicVector2();
            Z = 0;
            IsInRealm = false;
            FadeCounter = 10;
            Scale = 100;
        }
        public GameObject(LogicData data)
        {
            DataId = GlobalId.CreateGlobalId(data.GetClassId(), data.GetInstanceId());

            Position = new LogicVector2();
            Z = 0;

            FadeCounter = 10;
            Scale = 100;
        }

        public virtual void Tick()
        {
            ;
        }               

/*public virtual void Encode(BitStream bitStream, bool isOwnObject, int visionTeam = 0)
        {
            if (GetObjectType() == 3 && ((Item)this).ItemData.AlignToTiles)
            {
                bitStream.WritePositiveIntMax63(Position.X / 300);
                bitStream.WritePositiveIntMax63(Position.Y / 300);
                goto LABEL_15;
            }
            if (GetObjectType() == 1 && ((Projectile)this).ProjectileData.IgnoreLevelBoarder)
            {
                bitStream.WriteIntMax65535(Position.X);
                bitStream.WriteIntMax65535(Position.Y);
            }
            else
            {
                bitStream.WritePositiveVIntMax65535(Position.X);
                bitStream.WritePositiveVIntMax65535(Position.Y);
            }
            bitStream.WritePositiveVInt(RenderZ != -1 ? RenderZ : Z, 4);
            bitStream.WritePositiveVIntMax255(Index);
        LABEL_15:
            var t = GameObjectManager.GetBattle().GetPlayersCountWithGameModeVariation();
           if (GameObjectManager.GetBattle().GetGameModeVariation() == 30) t = 3;
           
           
        //    if (Index == -16) bitStream.WritePositiveVInt(17 * t, 3);
           //else bitStream.WritePositiveVInt(Index, 3);
        //    bitStream.WritePositiveIntMax1(0);//wtf???
        }*/
     
public virtual void Encode(BitStream bitStream, bool isOwnObject, int visionTeam = 0)
{
    int type = GetObjectType();   
    bool isPorn = false;

    if (type == 1 && this is Projectile proj)
    {
        int travelType = proj.ProjectileData.TravelType;

        if (travelType == 8 || travelType == 11)
            isPorn = true;
    }

    if (type != 1 && this is Projectile p2 && p2.ProjectileData != null)
    {
        
    }

    int x = Position.X;
    int y = Position.Y;

    if (type == 3 && this is Item item && item.ItemData.AlignToTiles)
    {
        bitStream.WritePositiveIntMax63(x / 300);
        bitStream.WritePositiveIntMax63(y / 300);
    }
    else
    {
        if (type == 1 && this is Projectile proj2 && proj2.ProjectileData.IgnoreLevelBoarder)
        {
            bitStream.WriteIntMax65535(x);
            bitStream.WriteIntMax65535(y);
        }
        else if (isPorn)
        {
            bitStream.WriteIntMax65535(x);
            bitStream.WriteIntMax65535(y);
        }
        else
        {
            bitStream.WritePositiveVIntMax65535(LogicMath.Clamp(x, 0, 65535));
            bitStream.WritePositiveVIntMax65535(LogicMath.Clamp(y, 0, 65535));
        }
    }

    int z = (RenderZ != -1 ? RenderZ : Z);
    bitStream.WritePositiveVIntMax65535(LogicMath.Clamp(z, 0, 65535));
    
    var battle = GameObjectManager.GetBattle();
    int t = battle.GetPlayersCountWithGameModeVariation();
    if (battle.GetGameModeVariation() == 30) t = 3;
    if (Index == -16) bitStream.WritePositiveVInt(Index, 3);
    else bitStream.WritePositiveVInt(Index, 3);

  /*  var battle = GameObjectManager.GetBattle();
    int v6 = battle.GetGameModeVariation(); //offset240 WHAT THIS 

    int v12 = this is Projectile p1 ? p1.TeamIndex : -1;
    int v13 = this is Projectile p3 ? p3.TeamIndex : -1;

    if (v12 == -1) v12 = v6;
    if (v13 == -1) v13 = v6;

    int packed = v12 + (16 * v13);*/
    int fade = GetFadeCounter();
  //bitStream.WritePositiveVIntMax255(GetFadeCounter());          

   if (this is Character ch)
   {
     if (isOwnObject)
     {
        fade = 15;
     }
    else if (ch.GetPlayer()?.TeamIndex == visionTeam)
    {
        fade = 15;
    }
}
   if (type != 1) 
    {
      bitStream.WritePositiveIntMax15(fade);
     }
  }
  
/*
public virtual void Encode(BitStream bitStream, bool isOwnObject, int visionIndex, int visionTeam)
    {
        var v1 = LogicMath.Clamp(_position.GetX(), 0, 65535);
        var v2 = LogicMath.Clamp(_position.GetY(), 0, 65535);
        var v3 = LogicMath.Clamp(GetZ(), 0, 65535);

        bitStream.WritePositiveVIntMax65535(v1);
        bitStream.WritePositiveVIntMax65535(v2);
        bitStream.WritePositiveVIntMax65535(v3);
        bitStream.WritePositiveVIntMax255(_index);
        if (GetFadeCounterClient() < 1 &&
            GetType() == ObjectTypeHelperTable.Character.GetObjectType() &&
            ((LogicCharacterServer)this).GetCharacterData().IsHero())
        {
            if (GetPlayer()!.GetTeamIndex() == visionTeam)
                bitStream.WritePositiveIntMax15(10 - 2);
            else if (!ShowedInInvisibleForTeams[visionTeam])
                bitStream.WritePositiveIntMax15(GetFadeCounterClient());
            else
                bitStream.WritePositiveIntMax15(10 - 2 - 2);
        }
        else if (GetType() != ObjectTypeHelperTable.Projectile.GetObjectType())
        {
            bitStream.WritePositiveIntMax15(GetFadeCounterClient());
        }
    }
*/

        public virtual void ResetEventsOnTick()
        {
            ;
        }

        public void SetForcedVisible()
        {
            FadeCounter = 10;
        }

        public void SetForcedInvisible()
        {
            FadeCounter = 0;
        }

        public GameObjectManager GetGameObjectManager()
        {
            return GameObjectManager;
        }

        public void IncrementFadeCounter()
        {
            if (FadeCounter < 10) FadeCounter++;
        }

        public void DecrementFadeCounter()
        {
            if (FadeCounter > 0) FadeCounter--;
        }

        public void SetFadeCounter(int counter)
        { FadeCounter = counter; }

        public int GetFadeCounter()
        {
            return FadeCounter;
        }

        public void SetPosition(int x, int y, int z)
        {
            Position.Set(x, y);
            Z = z;
        }

        public LogicVector2 GetPosition()
        {
            return Position.Clone();
        }

        public BattlePlayer GetPlayer()
        {
            BattleMode battle = GameObjectManager.GetBattle();
            int TeamIndex = Index / 16;
            int OwnIndex = Index % 16;
            foreach (BattlePlayer battlePlayer in battle.GetPlayers())
            {
                if (battlePlayer.TeamIndex == TeamIndex && battlePlayer.PlayerIndex == OwnIndex) return battlePlayer;
            }
            return null;
        }
        
        public BattlePlayer GetViewerPlayer()
{
    BattleMode battle = GameObjectManager.GetBattle();

    foreach (BattlePlayer battlePlayer in battle.GetPlayers())
    {
        if (battlePlayer.PlayerIndex == 0)
            return battlePlayer;
    }

    return null;
}

        public int GetGlobalID()
        {
            return ObjectGlobalId;
        }

        public int GetCloneOfObjectGlobalId()
        {
            return CloneOfObjectGlobalId;
        }

        public void SetCloneOfObjectGlobalId(int i)
        {
            CloneOfObjectGlobalId = i;
        }

        public int GetDataId()
        {
            return DataId;
        }
        public int GetCardValueForPassiveFromPlayer(string a2, int a3)
        {
            if (GetIndex() == -16) return -1;
            BattlePlayer v1 = GetPlayer();
            if (v1 == null) return -1;
            return v1.GetCardValueForPassive(a2, a3);
        }
        public void AttachGameObjectManager(GameObjectManager gameObjectManager, int globalId)
        {
            GameObjectManager = gameObjectManager;
            ObjectGlobalId = globalId;
        }

        public virtual bool ShouldDestruct()
        {
            return false;
        }

        public virtual void OnDestruct()
        {
            ;
        }
        public BattleMode GetBattle()
        {
            return GameObjectManager.GetBattle();
        }
        public int GetX()
        {
            return Position.X;
        }

        public int GetY()
        {
            return Position.Y;
        }

        public int GetZ()
        {
            return Z;
        }

        public void SetIndex(int i)
        {
            Index = i;
        }

        public int GetIndex()
        {
            return Index;
        }

        public int GetTeamIndex()
        {
            return Index % 16;
        }

        public virtual bool IsAlive()
        {
            return true;
        }

        public virtual int GetRadius()
        {
            return Scale;
        }

        public virtual int GetSize()
        {
            return 100;
        }

        public virtual int GetObjectType()
        {
            return -1;
        }
    }
}
